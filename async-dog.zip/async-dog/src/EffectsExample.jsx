import { useEffect, useState } from "react";

import axios from "axios";

function EffectsExample() {
  const [selectedId, setSelectedId] = useState(1);
  const [customer, setSelectedCustomer] = useState(null);

  // Usual way of using useEffect
  // useEffect(() => {
  //   const getCustomer = async (id) => {
  //     const response = await axios.get(
  //       `https://jsonplaceholder.typicode.com/users/${id}`,
  //     );
  //     // Simulate id 2 takes longer to load
  //     if (id === 2) await new Promise((resolve) => setTimeout(resolve, 3000));
  //     setSelectedCustomer(response.data);
  //   };

  //   getCustomer(selectedId);
  // }, [selectedId]);

  // Solution
  useEffect(() => {
    // Set a flag to ignore the result of the async function if the component unmounts or the effect is re-run
    let ignore = false;

    const getCustomer = async (id) => {
      const response = await axios.get(
        `https://jsonplaceholder.typicode.com/users/${id}`,
      );

      // Simulate id 2 takes longer to load
      if (id === 2) await new Promise((resolve) => setTimeout(resolve, 3000));
      if (!ignore) setSelectedCustomer(response.data);
    };

    getCustomer(selectedId);

    return () => {
      // Set the ignore flag to true when the component unmounts or the effect is re-run
      // Because the async function is still running, we don't want to update the state after the component has unmounted or the effect has re-run
      ignore = true;
    };
  }, [selectedId]);

  // useEffect(() => {
  //   let ignore = false;

  //   const getCustomer = async (id) => {
  //     const response = await axios.get(
  //       `https://jsonplaceholder.typicode.com/users/${id}`,
  //     );

  //     // Simulate id 2 takes longer to load
  //     if (id === 2) await new Promise((resolve) => setTimeout(resolve, 3000));
  //     setSelectedCustomer(response.data);

  //     // if (id == 2)
  //     //   setTimeout(() => {
  //     //     if (!ignore) setSelectedCustomer(response.data);
  //     //   }, 3000);
  //     // else if (!ignore) setSelectedCustomer(response.data);

  //     // Simulate id 2 takes longer to load
  //     // if (id == 2) setTimeout(() => setSelectedCustomer(response.data), 3000);
  //     // else setSelectedCustomer(response.data);

  //     // Usual update state
  //     setSelectedCustomer(response.data);
  //   };

  //   getCustomer(selectedId);

  //   return () => {
  //     ignore = true;
  //   };
  // }, [selectedId]);

  return (
    <div>
      <h1>Effects Example</h1>
      <button onClick={() => setSelectedId(1)} disabled={selectedId === 1}>
        1 - Leanne
      </button>
      <button onClick={() => setSelectedId(2)} disabled={selectedId === 2}>
        2 - Ervin
      </button>
      <button onClick={() => setSelectedId(3)} disabled={selectedId === 3}>
        3 - Clementine
      </button>
      {customer && (
        <div>
          <p>{customer.name}</p>
          <p>{customer.email}</p>
        </div>
      )}
    </div>
  );
}

export default EffectsExample;
