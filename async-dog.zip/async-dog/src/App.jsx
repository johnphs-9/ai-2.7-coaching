import { useEffect, useRef, useState } from "react";

import { v4 as uuidv4 } from "uuid";
import axios from "axios";
import { SyncLoader } from "react-spinners";

// const API_URL = "https://dog.ceo/api/breeds/image/random";
const API_URL = "/api/breeds/image/random";

let initialLoad = true;

function App() {
  const [dogs, setDogs] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const lastImgRef = useRef(null);

  // DO NOT DO THIS
  // Because setDog will cause component to re-render
  // axios.get(API_URL).then((response) => {
  //   console.log(response);
  //   // setDog(response.data.message);
  // });

  const getDog = async () => {
    try {
      setIsLoading(true);
      const response = await axios.get(API_URL);
      // ...prevState: spread out the prev array of dog urls
      setDogs((prevState) => [
        ...prevState,
        { id: uuidv4(), url: response.data.message },
      ]);
    } catch (error) {
      console.error(error);
    } finally {
      // console.log("this block will always run")
      setIsLoading(false);
    }
  };

  const get3Dogs = async () => {
    try {
      setIsLoading(true);

      // Calling sequentially
      // const result1 = await axios.get(API_URL);
      // const result2 = await axios.get(API_URL);
      // const result3 = await axios.get(API_URL);
      // setDogs((prevState) => [
      //   ...prevState,
      //   result1.data.message,
      //   result2.data.message,
      //   result3.data.message,
      // ]);

      // Create array of promises
      const promises = [
        axios.get(API_URL),
        axios.get(API_URL),
        axios.get(API_URL),
      ];

      // Use Promise.all combinator function
      // Call in parallel
      // const results = await Promise.all(promises);
      const [result1, result2, result3] = await Promise.all(promises);
      setDogs((prevState) => [
        ...prevState,
        { id: uuidv4(), url: result1.data.message },
        { id: uuidv4(), url: result2.data.message },
        { id: uuidv4(), url: result3.data.message },
      ]);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const clearDogs = () => {
    setDogs([]);
  };

  // Effects run twice in React 18 Strict Mode
  // This loads twice
  // useEffect(() => {
  //   // console.log("effect runs");
  //   getDog();
  // }, []);

  // But this only happens in development mode, not production
  // useEffect(effectFunction, dependencyArray)
  // useEffect(() => {
  //   // console.log("effect runs");

  //   if (initialLoad) {
  //     getDog();
  //     initialLoad = false;
  //   }
  // }, []);

  // https://react.dev/learn/synchronizing-with-effects#fetching-data
  // useEffect(() => {
  //   let ignore = false;

  //   async function initialFetch() {
  //     const result = await axios.get(API_URL);
  //     if (!ignore) {
  //       setDogs((prevState) => [...prevState, result.data.message]);
  //     }
  //   }

  //   initialFetch();

  //   return () => {
  //     ignore = true;
  //   };
  // }, []);

  // useEffect(() => {
  //   console.log("⏰ useEffect timer started");
  //   const myTimer = setInterval(() => {
  //     setSeconds((prevState) => prevState + 1);
  //   }, 1000);

  //   // Inject the chatbotscript.js into the DOM

  //   // Optional Cleanup Function
  //   // Runs when component unmounts or before effect re-runs
  //   return () => {
  //     console.log("useEffect timer cleaned up");
  //     clearInterval(myTimer);

  //     // Remove the chatbotscript.js from the DOM
  //   };
  // }, []);

  // Use useEffect to listen to keypress events
  useEffect(() => {

    // inject the chatbotscript.js into the DOM
    const handleKeyPress = (event) => {
      console.log(`Key pressed: ${event.code}`);
      if (event.code == "Digit1") {
        getDog();
      }
      if (event.code == "Digit3") {
        get3Dogs();
      }
      // listen for character c
      if (event.code == "KeyC") {
        clearDogs();
      }
    };

    document.addEventListener("keydown", handleKeyPress);

    // Cleanup function
    return () => {
      document.removeEventListener("keydown", handleKeyPress);

      // remove chatbotscript.js from the DOM
    };
  }, []);

  useEffect(() => {
    // If there are no dogs, do nothing
    if (!lastImgRef.current) return;

    // Scroll to the last image
    lastImgRef.current.scrollIntoView({ behavior: "smooth" });

    // This effect will run whenever dogs change
  }, [dogs]);

  return (
    <>
      <h1>Async and useEffect Demo</h1>
      <div className="instructions">
        Hit <span className="keybox">1</span> or{" "}
        <span className="keybox">3</span> to load dogs,{" "}
        <span className="keybox">c</span> to clear all dogs!
      </div>
      <div className="buttons-container">
        <button onClick={getDog} disabled={isLoading}>
          Get Dog
        </button>
        <button onClick={get3Dogs} disabled={isLoading}>
          Get 3 Dogs
        </button>
        <button onClick={clearDogs}>Clear Dogs</button>
        <Timer />
      </div>

      {dogs.length === 0 && <p>No dogs available.</p>}
      {dogs.length > 0 && (
        <div className="dogs-container">
          {dogs.map((dog, i) => (
            <img
              key={dog.id}
              src={dog.url}
              alt="dog"
              className="dog-item"
              // If it's the last image, set the ref
              ref={i === dogs.length - 1 ? lastImgRef : null}
            />
          ))}
          {isLoading && (
            <div className="spinner-container">
              <SyncLoader color="#5f3dc4" />
            </div>
          )}
        </div>
      )}
    </>
  );
}

function Timer() {
  const [seconds, setSeconds] = useState(0);

  // useEffect(() => {
  //   console.log("⏰ useEffect timer started");
  //   setInterval(() => {
  //     setSeconds((prevState) => prevState + 1);
  //   }, 1000);
  // }, []);

  useEffect(() => {
    console.log("⏰ useEffect timer started");
    const myTimer = setInterval(() => {
      setSeconds((prevState) => prevState + 1);
    }, 1000);

    // Optional Cleanup Function
    // Runs when component unmounts or before effect re-runs
    return () => {
      console.log("useEffect timer cleaned up");
      clearInterval(myTimer);
    };
  }, []);

  return <div style={{ marginLeft: 20 }}>{seconds}s passed.</div>;
}

export default App;
