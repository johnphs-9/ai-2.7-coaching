CORS - Cross Origin Resource Sharing

React app is on http://www.mysite.com API is on same site ✅

React app is on http://www.mysite.com API is someapi.com ❌ maybe a CORS issue

CORS enforced by the browser

CORS
block all localhost

React App <-> API Server (CORS)

React App <-> Proxy Server <-> API Server

Backend API server needs update their headers to allow your origin.


Page

About /about
Customers /customers

Dashboard /dashboard  authCtx.isLoggedIn &&


const item = useRef()


item.scrollToView

