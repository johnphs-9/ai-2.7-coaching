# Demo Code for React

This is a simple React app that demonstrates the use of the useEffect hook.