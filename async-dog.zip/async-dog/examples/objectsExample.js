/*=============================================
=            Quick Review on Objects          =
=============================================*/

// Copying and assigning primitive types
let a = 5;
let b = a;

// copying a to b
console.log(a);
console.log(b);

// changing a to 10
a = 10;
console.log(a);
console.log(b);
// a and b remain independent of each other because they are primitive types

// Let's create an object
const johnObj = {
  title: 'Mr',
  firstName: 'John',
  lastName: 'Lee',
  job: {
    company: 'IBM',
    role: 'Manager',
  },
};

// Try to make a copy of the object
const georgeObj = johnObj; // reference - it gets the address of the john object
// now both george and john will have the reference

// Take a look at the outputs
console.log('😎 John: ', johnObj);
console.log('😃 George copied John: ', georgeObj);

// And change George's name
// georgeObj.firstName = 'George';
// georgeObj.lastName = 'Tan';

// Does it look right?
// console.log('🪄 ✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨');
console.log('😎 Original John: ', johnObj);
console.log('😃 Updated George: ', georgeObj);

// Why does this happen?
// Because objects are reference types

// So how do we copy?

// Remember the spread operator?
console.log('Spread John', { ...johnObj });

// now let's copy using the spread operator
const georgeObj2 = {
  ...johnObj,
  job: {
    ...johnObj.job,
  },
};
georgeObj2.firstName = 'George';
georgeObj2.lastName = 'Tan';
georgeObj2.job.company = 'Apple';

// Now does it look right?
console.log('John', johnObj);
console.log('John job', johnObj.job)
console.log('George', georgeObj2);
// console.log('🪄 ✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨');
// console.log('😎 Original John: ', johnObj);
// console.log('😃 Updated George (Spread): ', georgeObj2);

// To make it similar to our React example
const georgeObj3 = {
  ...johnObj, // copy the johnObj
  // update the keys that I want

  // last declared key/value pair
  firstName: 'George',
  lastName: 'Tan',
};
// console.log('🪄 ✨✨✨✨✨✨✨✨✨✨✨✨✨✨✨');
console.log('😎 Original John: ', johnObj);
console.log('😃 New George (Spread): ', georgeObj3);

