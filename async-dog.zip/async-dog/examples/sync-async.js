// Synchronous code
// console.log('START');
// console.log('MIDDLE');
// console.log('END');


// Synchronous code with long for loop
// console.log('START');
// // Block the main thread
// for (let i = 0; i < 10000000000; i++) {
//   // do nothing
// }
// console.log('MIDDLE');
// console.log('END');


// Asynchronous code
// What will the output be?
console.log("START");
setTimeout(() => console.log("MIDDLE - 0s"), 0); // 0s timer
setTimeout(() => console.log("MIDDLE - 2s"), 2000); // 2s timer
console.log("END");

